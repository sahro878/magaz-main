import React from 'react';

const Basket = () => {
    return (
        <div>
            basket
        </div>
    );
};

export default Basket;
